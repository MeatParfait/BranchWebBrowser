﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace BranchWebBrowser
{
/// <summary>
/// MainWindow.xaml에 대한 상호 작용 논리
/// </summary>
public partial class MainWindow : Window
   {
      bool isBranchPanelActive = false;

      Regex domainRegex = new Regex(@"\.[a-zA-Z]+");

      enum TileType
      {
         None,
         Node,
         Line
      }
      struct Tile
      {
         public UIElement uIElement;
         public TileType tileType;
      }

      int scaleX = 150, scaleY = 100;
      int offset = 50;

      
      public MainWindow()
      {
         InitializeComponent();

         //manager에 연결
         WebPageManager.mainWindow = this;
         BranchManager.mainWindow = this;

         //prefab 등록
         UIElementUtil.RegisterPrefab(webBrowser_prefab);
         UIElementUtil.RegisterPrefab(webPageTab_prefab);
         UIElementUtil.RegisterPrefab(BranchNode_prefab);
         UIElementUtil.RegisterPrefab(BranchLine_prefab);
         //prefab 제거
         webBrowserPanel.Children.Remove(webBrowser_prefab);
         webpagePanel.Children.Remove(webPageTab_prefab);
         branchGrid.Children.Remove(BranchNode_prefab);
         branchGrid.Children.Remove(BranchLine_prefab);

         //IE11으로 설정
         Registry.SetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_BROWSER_EMULATION", "BranchWebBrowser.exe", 11000);
      }


      private void EraseUrl_Click(object sender, RoutedEventArgs e)
      {
         urlTextBox.Text = "";
      }

      private void NewBranchButton_Click(object sender, RoutedEventArgs e)
      {
         SaveFileDialog saveFileDialog = new SaveFileDialog();
         saveFileDialog.AddExtension = true;
         saveFileDialog.DefaultExt = ".brc";
         saveFileDialog.Filter = "brc files (*.brc)|*.brc";
         saveFileDialog.Title = "가지 파일(.brc) 저장";
         if (saveFileDialog.ShowDialog() == true)
         {
            BranchManager.filePath = saveFileDialog.FileName;
            
            //빈 파일 하나 만들기
            File.WriteAllText(BranchManager.filePath, "");
            
            if(WebPageManager.currentWebPage == null)
            {
               BranchManager.currentMainBranch = new Branch("빈 가지", "");
            }
            else
            {
               BranchManager.currentMainBranch = new Branch(WebPageManager.currentWebPage.currentTitle,
                                                            WebPageManager.currentWebPage.currentUrl);
            }
            SaveTree();

            LoadTree();
            DrawTree();
            ShowTreePanel();
         }
      }
      private void OpenBranchButton_Click(object sender, RoutedEventArgs e)
      {
         OpenFileDialog openFileDialog = new OpenFileDialog();
         openFileDialog.DefaultExt = ".brc";
         openFileDialog.Filter = "brc files (*.brc)|*.brc";
         openFileDialog.Title = "가지 파일(.brc) 열기";
         if (openFileDialog.ShowDialog() == true)
         {
            BranchManager.filePath = openFileDialog.FileName;

            LoadTree();
            DrawTree();
            ShowTreePanel();
         }
      }
      private void AddBranchButton_Click(object sender, RoutedEventArgs e)
      {
         Branch newBranch;
         if(WebPageManager.currentWebPage == null)
         {
            newBranch = new Branch("빈 가지", "");
         }
         else
         {
            newBranch = new Branch(WebPageManager.currentWebPage.currentTitle,
                                   WebPageManager.currentWebPage.currentUrl);
         }
         //부모 자식 연결
         if (BranchManager.currentBranchNode != null)
            BranchManager.currentBranchNode.children.Add(newBranch);

         BranchManager.currentBranchNode = newBranch;

         DrawTree();
          
         addBranchGrid.Visibility = Visibility.Visible;
         addBrcTitleTextBox.Text = BranchManager.currentBranchNode.title;
         addBrcUrlTextBox.Text = BranchManager.currentBranchNode.url;
      }

      public void DrawTree()
      {
         //branch 테스트용
         //Branch testBranch = new Branch("a", "");
         //Branch cb1 = new Branch("b", "");
         //Branch cb2 = new Branch("c", "");
         //Branch cb3 = new Branch("d", "");
         //Branch cb4 = new Branch("e", "");
         //testBranch.children.Add(cb1);
         //testBranch.children.Add(cb2);
         //testBranch.children.Add(cb3);
         //testBranch.children.Add(cb4);
         //BranchManager.currentMainBranch = testBranch;

         int currentStep = 0, maxLayer = 10, maxStep = 10;
         
         //지우고 다시 그리기
         EraseTree();

         //map 배열 크기 계산
         void CalculateTileSize(Branch branch)
         {
            if (branch.children.Count == 0)
            {
               maxStep++;
               return;
            }
            else
            {
               maxLayer++;
         
               for (int i = 0; i < branch.children.Count; i++)
               {
                  CalculateTileSize(branch.children[i]);
               }
            }
         }
         CalculateTileSize(BranchManager.currentMainBranch);
         Tile[,] map = new Tile[maxLayer * 2 - 1, maxStep];
         branchGrid.Width = maxLayer * scaleX + offset + 50;
         branchGrid.Height = maxStep * scaleY + offset;


         //타일 등록
         void SetTiles(Branch branch, int layer)
         {
            int currentLayer = layer;

            if (branch == BranchManager.currentBranchNode)
            {
               SetTile(map, currentLayer, currentStep, TileType.Node,
                     branch: branch, isCurrentNode: true);
            }
            else
            {
               SetTile(map, currentLayer, currentStep, TileType.Node,
                     branch: branch);
            }

            if(branch.children.Count == 0)
            {
               currentStep++;
               return;
            }

            currentLayer++;
            int i = 0;
            for (i = 0; i < branch.children.Count; i++)
            {
               int previousStep = currentStep;

               SetTiles(branch.children[i], currentLayer + 1);

               if (i == branch.children.Count - 1)
               {
                  SetTile(map, currentLayer, previousStep, TileType.Line);
               }
               else
               {
                  for (; previousStep < currentStep; previousStep++)
                  {
                     SetTile(map, currentLayer, previousStep, TileType.Line);
                  }
               }
            }
         }
         SetTiles(BranchManager.currentMainBranch, 0);


         //타일 그리기
         for (int y = 0; y < map.GetLength(1); y++)
         {
            for (int x = 0; x < map.GetLength(0); x++)
            {
               DrawTile(map, x, y);
            }
         }
      }
      private void SetTile(Tile[,] map, int x, int y, 
                           TileType tileType,
                           Branch branch = null, bool isCurrentNode = false)
      {
         //TODO 디버깅용
         //이미 쓴 공간이면 돌아가기
         //if (map[x, y].tileType != TileType.None)
         //{
         //   (map[x, y].uIElement as Grid).Background = Brushes.MediumVioletRed;
         //   return;
         //}

         //branch node
         if(tileType == TileType.Node)
         {
            //branchNode 복제
            Grid newBranchNode = UIElementUtil.ClonePrefab(BranchNode_prefab) as Grid;
            UIElementCollection childrenOfNode = newBranchNode.Children;
            branch.TitleButton = childrenOfNode[0] as Button;
            //if(isCurrentNode)
            //{
            //   branch.TitleButton.Background = Brushes.Yellow;
            //}
            
            map[x, y].uIElement = newBranchNode;
            map[x, y].tileType = TileType.Node;
         }
         //branch space
         else if(tileType == TileType.Line)
         {
            //branchSpace 복제
            Grid newBranchNodeSpace = UIElementUtil.ClonePrefab(BranchLine_prefab) as Grid;

            map[x, y].uIElement = newBranchNodeSpace;
            map[x, y].tileType = TileType.Line;
         }
      }
      private void DrawTile(Tile[,] map, int x, int y)
      {
         Tile tile = map[x, y];
         if(tile.tileType == TileType.Node)
         {
            branchGrid.Children.Add(tile.uIElement);
            ((Grid)tile.uIElement).Margin = new Thickness(x * scaleX + offset, y * scaleY + offset + 15, 0.0, 0.0);

         }
         else if(tile.tileType == TileType.Line)
         {
            ImageBrush image = new ImageBrush();
            TileType upTile = TileType.None, 
                     downTile = TileType.None, 
                     leftTile = TileType.None,
                     rightTile = TileType.None;
            if (x - 1 >= 0) leftTile = map[x - 1, y].tileType;
            if (x + 1 < map.GetLength(0)) rightTile = map[x + 1, y].tileType;
            if (y - 1 >= 0) upTile = map[x, y - 1].tileType;
            if (y + 1 < map.GetLength(1)) downTile = map[x, y + 1].tileType;

            if (upTile == TileType.Line && rightTile == TileType.Node)
               image.ImageSource = new BitmapImage(new Uri(@"pack://application:,,,/Resources/LastChild.png"));

            else if (leftTile == TileType.Node && rightTile == TileType.Node)
               image.ImageSource = new BitmapImage(new Uri(@"pack://application:,,,/Resources/AChild.png"));

            else
               image.ImageSource = new BitmapImage(new Uri(@"pack://application:,,,/Resources/VerticalLine.png"));
            

            branchGrid.Children.Add(tile.uIElement);
            ((Grid)tile.uIElement).Margin = new Thickness(x * scaleX + offset + 50, y * scaleY + offset, 0.0, 0.0);
            ((Grid)tile.uIElement).Background = image;
         }
      }

      private void EraseTree()
      {
         branchGrid.Children.Clear();
      }
      private void SaveTree()
      {
         BinaryFormatter binaryFormatter = new BinaryFormatter();
         Stream fs = new FileStream(BranchManager.filePath, FileMode.Open, FileAccess.Write);
         binaryFormatter.Serialize(fs, BranchManager.currentMainBranch);
         fs.Close();
      }
      private void LoadTree()
      {
         EraseTree();

         BinaryFormatter binaryFormatter = new BinaryFormatter();
         Stream fs = new FileStream(BranchManager.filePath, FileMode.Open, FileAccess.Read);
         BranchManager.currentMainBranch = (Branch)binaryFormatter.Deserialize(fs);
         fs.Close();
         
         addBranchButton.Visibility = Visibility.Visible;
         ShowBranchButton.Visibility = Visibility.Visible;
         saveBranchButton.Visibility = Visibility.Visible;
      }

      private void urlTextBox_KeyDown(object sender, KeyEventArgs e)
      {
         //focus 지우기
         if (e.Key == Key.Escape)
         {
            Keyboard.ClearFocus();
         }

         //입력한 url 검색
         if (e.Key == Key.Enter)
         {
            OpenUrl(urlTextBox.Text);
         }
      }
      public void OpenUrl(string url, bool createNewWebPage = false)
      {
         Keyboard.ClearFocus();

         //빈 주소면 변경 안함
         if (url == "" || url == null)
            return;

         if (domainRegex.IsMatch(url) == false)
         {
            url = string.Format("https://www.google.co.kr/search?hl=ko&ei=R5AcW42SDoO20QSphpSoAg&q={0}", url);
         }
         else if (url.StartsWith("http://") == false && url.StartsWith("https://") == false)
         {
            url = "http://" + url;
         }

         //열려있는 창이 없으면 하나 만들기
         if (WebPageManager.currentWebPage == null)
         {
            newWebPageButton_Click(null, null);
         }

         WebPageManager.currentWebPage.webBrowser.Navigate(url);
         HideTreePanel();
      }

      private void GoForwardButton_Click(object sender, RoutedEventArgs e)
      {
         //열려있는 창이 없으면 나가기
         if (WebPageManager.currentWebPage == null)
            return;

         if (WebPageManager.currentWebPage.webBrowser.CanGoForward)
         {
            WebPageManager.currentWebPage.webBrowser.GoForward();
         }
      }
      private void GoBackwardButton_Click(object sender, RoutedEventArgs e)
      {
         //열려있는 창이 없으면 나가기
         if (WebPageManager.currentWebPage == null)
            return;

         if (WebPageManager.currentWebPage.webBrowser.CanGoBack)
         {
            WebPageManager.currentWebPage.webBrowser.GoBack();
         }
      }

      public void ShowTreePanel()
      {
         isBranchPanelActive = true;

         WebPageManager.ActivateOneWebpage(null);
         branchScrollViewer.Visibility = Visibility.Visible;
         helpTextBlock.Visibility = Visibility.Visible;
      }
      public void HideTreePanel()
      {
         isBranchPanelActive = false;

         WebPageManager.ActivateOneWebpage(WebPageManager.currentWebPage);
         branchScrollViewer.Visibility = Visibility.Hidden;
         helpTextBlock.Visibility = Visibility.Hidden;
      }

      private void ShowBranchButton_Click(object sender, RoutedEventArgs e)
      {
         if(isBranchPanelActive == true)
         {
            HideTreePanel();
         }
         else
         {
            ShowTreePanel();
         }
      }

      private void newWebPageButton_Click(object sender, RoutedEventArgs e)
      {
         //webpage tab 생성
         Grid newWebPage = UIElementUtil.ClonePrefab(webPageTab_prefab) as Grid;
         UIElementCollection children = newWebPage.Children;
         webpagePanel.Children.Add(newWebPage);

         //web browser 생성
         WebBrowser newWebBrowser = UIElementUtil.ClonePrefab(webBrowser_prefab) as WebBrowser;
         webBrowserPanel.Children.Add(newWebBrowser);
         
         new WebPage(newWebBrowser, 
                     newWebPage,
                     children[0] as Button, 
                     children[1] as Button);
      }

      private void branchGrid_KeyDown(object sender, KeyEventArgs e)
      {
         //추가
         if(e.Key == Key.A && Keyboard.IsKeyDown(Key.LeftCtrl))
         {
            AddBranchButton_Click(null, null);
         }

         //수정
         if (e.Key == Key.E && Keyboard.IsKeyDown(Key.LeftCtrl))
         {
            addBranchGrid.Visibility = Visibility.Visible;
            addBrcTitleTextBox.Text = BranchManager.currentBranchNode.title;
            addBrcUrlTextBox.Text = BranchManager.currentBranchNode.url;
         }

         //제거
         if (e.Key == Key.Delete)
         {
            bool isDone = false;
            void FindMeAndKill(Branch branch)
            {
               if(branch.children.Count == 0 || isDone)
               {
                  return;
               }
               else
               {
                  for (int i = 0; i < branch.children.Count; i++)
                  {
                     if(branch.children[i] == BranchManager.currentBranchNode)
                     {
                        branch.children.Remove(BranchManager.currentBranchNode);
                        isDone = true;
                        return;
                     }
                     else
                     {
                        FindMeAndKill(branch.children[i]);
                     }
                  }
               }
            }
            FindMeAndKill(BranchManager.currentMainBranch);
            DrawTree();
         }
      }

      private void settingButton_Click(object sender, RoutedEventArgs e)
      {
      }

      private void admitAddbranchButton_Click(object sender, RoutedEventArgs e)
      {
         addBranchGrid.Visibility = Visibility.Hidden;
         BranchManager.currentBranchNode.title = addBrcTitleTextBox.Text;
         BranchManager.currentBranchNode.url = addBrcUrlTextBox.Text;

         DrawTree();
      }

      private void SaveBranchButton_Click(object sender, RoutedEventArgs e)
      {
         SaveTree();
      }
   }
}
